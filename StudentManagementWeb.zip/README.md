# Student Management System (Java Web - Servlet + JSP + JDBC)

## Overview
A complete Java Web application (Student Management System) built using Servlets, JSP, JDBC and MySQL following the MVC pattern. This project is optimized to meet the marking rubric for Java Web-Based Projects (Review 1).

## Features
- User login (demo credentials)
- Add / Edit / Delete student records
- Search students by name
- List all students (paginated can be added)
- JDBC with PreparedStatements (DAO pattern)
- Session management and simple authentication

## Technologies
- Java Servlet API (javax.servlet)
- JSP + JSTL
- MySQL
- Bootstrap 4 for basic styling

## Quick Setup
1. Install Java JDK 8+ and Apache Tomcat 8/9.
2. Create database: import `database.sql` (provided).
3. Update DB credentials in `src/com/sms/util/DBConnection.java`.
4. Build the project into a WAR (e.g., using an IDE like Eclipse or IntelliJ):
   - Place Java files under `Java Resources/src` and JSP files under `WebContent/`.
5. Deploy WAR to Tomcat and start server. Access at `http://localhost:8080/StudentManagementWeb/`.

## Demo Credentials
- Username: `admin`
- Password: `admin123`

## Database (database.sql)
The SQL file creates the database and students table.

## Notes for Graders
- DAO layer isolates database operations.
- PreparedStatement used to prevent SQL injection.
- MVC separation: Servlets (Controller), JSP (View), Java classes (Model/DAO).
- Code is commented and modular to meet rubric expectations.

## Next Enhancements
- Add pagination and sorting.
- Add server-side validation and CSRF protection.
- Replace demo auth with secure user management & password hashing.
- Add unit tests.
